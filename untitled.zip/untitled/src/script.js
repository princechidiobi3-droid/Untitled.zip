
document.addEventListener("DOMContentLoaded", () => {
  const startBtn = document.getElementById("startBtn");
  const newsletterForm =
    document.getElementById("newsletterForm");
  const emailInput = document.getElementById("email");
  const message = document.getElementById("message");

  // Get Started button
  startBtn.addEventListener("click", () => {
    document.getElementById("contact").scrollIntoView({
      behavior: "smooth"
    });

    emailInput.focus();
  });

  // Newsletter subscription form
  newsletterForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const email = emailInput.value.trim();

    if (!emailInput.checkValidity() || email === "") {
      message.textContent =
        "Please enter a valid email address.";
      emailInput.focus();
      return;
    }

    message.textContent =
      "Thank you! Your email has been entered successfully.";

    newsletterForm.reset();
  });
});
